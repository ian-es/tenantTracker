public class AnnualReport{
  private rentRecord rents;
  private expenseRecord expenses;


  /**Constructor for Annual Reports
  */
  public AnnualReport(){
    rents = new rentRecord();
    expenses = new expenseRecord();
  }
  
  /**
  */
  public void printReport(){
    System.out.println("Annual Summary\n--------------\nIncome");
    System.out.println("Rent "+String.format("%,.2f", rents.sum()));
    System.out.print("\nExpenses");
    System.out.println(expenses.categorySums());
    double sum = (rents.sum()-expenses.sum());
    System.out.println("\nBalance "+String.format("%,.2f", sum));
  }
}