import java.io.*;
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    String llName = "";
    String llPw = "";
    userInterface UI = new userInterface();

    System.out.println("Welcome to the tenantTracker program.");
    
    try {
      File dataFile = new File("data.txt");
      Scanner readFile = new Scanner(dataFile);

      if (!readFile.hasNextLine()){
        FirstlogIn();
        readFile = new Scanner(dataFile);
      }
      llName = readFile.nextLine();
      llPw = readFile.nextLine();
      
      readFile.close();
    }
    catch (FileNotFoundException fnf){
      System.out.println("Exception: data file was not found.");
    }
    
    logIn(llName,llPw);
    UI.displayMainMenu();
    
  }

  /** Handle first time log in case by writing username and pass to first two lines of data.txt
  */
  public static void FirstlogIn(){
    
    Scanner in = new Scanner(System.in);
    System.out.println("First time login.\nPlease enter your name: ");
    String name = in.nextLine();

    System.out.println("Create a password for future logins: ");
    String pass = in.nextLine();

    try{
      PrintWriter writer = new PrintWriter("data.txt");
      writer.println(name);
      writer.println(pass);
      writer.close();
    }
    catch (FileNotFoundException fnf){
      System.out.println("Exception: data file was not found.");
    }
  }

  /***/
  public static void logIn(String name, String pass){
    boolean valid = false;
    Scanner in = new Scanner(System.in);
    
    System.out.println("\nHello, "+name+"!");
    while (!valid){
      System.out.print("\nPlease enter password: ");
      if(in.nextLine().equals(pass)){
        valid = true;
      }
      else{
        System.out.println("Incorrect password.");
      }
    }
  }
}