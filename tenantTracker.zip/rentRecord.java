import java.io.*;
import java.util.*;
import java.util.Scanner;

public class rentRecord{
  private ArrayList<RentRow> list = new ArrayList<RentRow>();
  /** Default constructor for rentRecord, checks for existing rentRows in data files
  */
  public rentRecord(){
    try{
      File dataFile = new File("rent.txt");
      Scanner readFile = new Scanner(dataFile);
      String input;
      
      while (readFile.hasNext()){
        RentRow rent = new RentRow();
        input = readFile.next();
        rent.setApt(Integer.parseInt(input));
        for (int i=1;i<=12;i++){
          input = readFile.next();
          rent.addPayment(Double.parseDouble(input),i);
        }
      list.add(rent);
      }
      readFile.close();
    }
    catch(FileNotFoundException fnf){
      System.out.println("Error reading file.");
    }
  }
  /**Given a rent row as an input, adds it to the internal list (and updates text document)
  @param rent rent to be added
  @return success of adding rent to files
  */
  public boolean addRent(RentRow rent){
    list.add(rent);
    Collections.sort(list);
    try{
      PrintWriter writer = new PrintWriter("rent.txt");
      
      writer.print(this.toString());
      writer.close();
      return true;
    }
    catch (FileNotFoundException fnf){
      System.out.println("Exception: data file was not found.");
    }
    System.out.println("Error. Rent was unable to be added to files.");
    return false;
  }

  public double sum(){
    double sum = 0;
    for (RentRow rent:list){
      sum += rent.getPaid();
    }
    return sum;
  }

  /**Displays to the console the rent records in the correct format: column for apt numbers and subsequent columns for each month, rows populated with the rents respective to each apt.
  */
  @Override
  public String toString(){
    String rents = "";
      for (int i = 0;i<list.size();i++){
        rents += list.get(i) + "\n";
      }
    return rents;
  }
}