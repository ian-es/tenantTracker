import java.util.Scanner;

public class expenseInput{
  private expenseRecord records = new expenseRecord();

  /**Through user prompts, adds another expense to the records
  */
  public void create(){
    Expense expense = new Expense();
    Scanner in = new Scanner(System.in);
    String input;
    boolean success = false;
    
    while (!success){
      System.out.print("\nEnter month (1-12): ");
      input = in.next();
      try{
        int month = Integer.parseInt(input);
        success = expense.setMonth(month);
        if (!success){
        System.out.println("Invalid range.");
        }
      }
      catch(NumberFormatException e){
        System.out.println("Invalid format.");
      }
    }

    success = false;
    while (!success){
      System.out.print("\nEnter day (1-31): ");
      input = in.next();
      try{
        int day = Integer.parseInt(input);
        success = expense.setDay(day);
        if (!success){
        System.out.println("Invalid range.");
        }
        
      }
      catch(NumberFormatException e){
        System.out.println("Invalid format.");
      }
    }

    in.nextLine();
    success = false;
    while (!success){
      System.out.print("\nEnter expense category (Repairing, Utilities): ");
      input = in.nextLine();
      success = expense.setCategory(input);
      if (!success){
        System.out.println("Invalid input.");
      }
    }

    success = false;
    while (!success){
      System.out.print("\nEnter payee (Bob's Hardware, Big Electric Co): ");
      input = in.nextLine();
      success = expense.setPayee(input);
      if (!success){
        System.out.println("Invalid input.");
      }
    }

    success = false;
    while (!success){
      System.out.print("\nEnter amount (39.95): ");
      input = in.next();
      if (input.indexOf('.')!= -1 && (input.length() -  (input.indexOf('.')+1))>2) {
        System.out.println("Invalid decimal format.");
        continue;
      }
      try{
        double paid = Double.parseDouble(input);
        success = expense.setPayment(paid);
        if (!success){
        System.out.println("Please enter a positive number.");
        }
      }
     catch(NumberFormatException e){
        System.out.println("Invalid format.");
      }
    }
    records.addExpense(expense);
  }

  /** Displays all expenses
  */
  public void display(){
    System.out.println("Date Payee Amount Category\n----------------------------------------");
    System.out.println(records);
  }
}