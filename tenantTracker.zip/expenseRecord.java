import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class expenseRecord{
  private ArrayList<Expense> list = new ArrayList<Expense>();

  /** Default constructor for expenseRecord, checks for existing expense records saved in the text document
  */
  public expenseRecord(){
    try{
      File dataFile = new File("expenses.txt");
      Scanner readFile = new Scanner(dataFile);
      String payee;
      String input;
      double amount =0;

      while(readFile.hasNext()){
        Expense expense = new Expense();
        boolean flag = false;
        input = readFile.next();
        expense.setMonth(Integer.parseInt(input.split("/")[0]));
        expense.setDay(Integer.parseInt(input.split("/")[1]));
        input = readFile.next();
        payee = input;
        while (!flag){
          input = readFile.next();
          try{
            amount = Double.parseDouble(input);
            flag = true;
          }
          catch(NumberFormatException e){
            payee += " "+input;
          }
        }
        expense.setPayee(payee);
        expense.setPayment(amount);
        expense.setCategory(readFile.nextLine().trim());
        list.add(expense);
      }
      readFile.close();
    }
    catch(FileNotFoundException fnf){
      System.out.println("Exception: data file was not found.");
    }
  }

  /**Given an expense as an input, adds it to the internal list (and updates text document)
  @param expense expense to be added
  @return success of adding expense to files
  */
  public boolean addExpense(Expense expense){
    list.add(expense);
    Collections.sort(list);

    try{
      PrintWriter writer = new PrintWriter("expenses.txt");
      
      writer.print(this.toString());
      writer.close();
      return true;
    }
    catch (FileNotFoundException fnf){
      System.out.println("Exception: data file was not found.");
    }
    System.out.println("Error. Expense was unable to be added to files.");
    return false;
  }

  public double sum(){
    double sum = 0;
    for (Expense expense:list){
      sum += expense.getPaid();
    }
    return sum;
  }
  
  public String categorySums(){
    String output = "";
    Map <String,Double> categorySums =  list.stream().collect(Collectors.groupingBy(Expense::getCategory, Collectors.summingDouble(Expense::getPaid)));

    for(Map.Entry<String,Double> pair:categorySums.entrySet()){
      output += "\n"+pair.getKey()+" "+String.format("%,.2f", pair.getValue());
    }
    return output;
  }

  @Override
  public String toString(){
    String expenses = "";
      for (int i = 0;i<list.size();i++){
        expenses += list.get(i) + "\n";
      }
    return expenses;
  }
}
