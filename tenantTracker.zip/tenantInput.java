import java.util.Scanner;

public class tenantInput{
  private tenantList tenants = new tenantList();

  public void create(){
    Scanner in = new Scanner(System.in);
    Tenant tenant = new Tenant();
    String input = "";
    Boolean success = false;

    //giving tenant a name
    while (!success){
      System.out.print("\nEnter tenant's name (George Smith): ");
      input = in.nextLine().trim();
      // checking list of tenants for name
      if (tenants.contains(input)){
        System.out.println("Tenant is aleady in system.");
        return;
      }
      success = tenant.addName(input);
      if(!success){System.out.println("Invalid format");}
    }
    success = false;

    //giving tenant an apartment
    while (!success){
      System.out.print("\nEnter tenant's apartment number (101): ");
      input = in.next();
      int apt = 0;
      try{
        apt = Integer.parseInt(input);
        if (tenants.contains(apt)){
          System.out.println("Apartment is already occupied.");
          return;
        }
        success = tenant.addApt(apt);
        if(!success){System.out.println("Invalid format");}
      }
      catch(NumberFormatException e){
        System.out.println("Invalid format");
      }
    }
    tenants.addTenant(tenant);
  }

  public void display(){
    System.out.println("Apt# Tenant name\n-------------------");
    System.out.println(tenants);
  }
}