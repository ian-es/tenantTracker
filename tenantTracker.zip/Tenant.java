public class Tenant implements Comparable<Tenant>{
  private String name;
  private int aptNum;


  public Tenant(){
    name = null;
    aptNum = -1;
  }
  /**Setter for tenant name
  @param tenantName user inputted tenant name
  @return if name change was valid
  */
  public boolean addName(String tenantName){
    if (!tenantName.equals("")){
      name = tenantName;
      return true;
    }
    return false;
  }

  /**Setter for apt num
  @param apt user inputted apartment number
  @return if apartment number was valid
  */
  public boolean addApt(int apt){
    if (apt<100 || apt >999){
      return false;
    }
    aptNum = apt;
    return true;
  }
  
  /** Getter for tenant name
  @return name
  */
  public String getName(){
    return name;
  }
  
  /**Getter for tenant apartment
  @return apartment number
  */
  public int getApt(){
    return aptNum;
  }

  @Override
  public String toString(){
    return String.valueOf(aptNum)+" "+name;
  }

  @Override
  public int compareTo(Tenant tenant){
    return this.name.compareTo(tenant.getName());
  }

  @Override
  public boolean equals(Object o){
    if (o instanceof Tenant){
      String compare = ((Tenant)o).getName();
      return name.equals(compare);
    }
    return false;
  }

  @Override
  public int hashCode() {
    return name.hashCode();
  }
}