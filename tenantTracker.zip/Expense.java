public class Expense implements Comparable<Expense>{
  private int payMonth;
  private int payDay;
  private String category;
  private String payee;
  private double paid;

  /**Constructor for Expense
  */
  public Expense(){
  }

  public boolean setMonth(int month){
    if (month <1 || month >12){
      return false;
    }
    payMonth = month;
    return true;
  }
  public boolean setDay(int day){
    if (day<1 || day>31){
      return false;
    }
    payDay = day;
    return true;
  }
  public boolean setCategory(String ctgry){
    if(ctgry.equals("")){
      return false;
    }
    category = ctgry;
    return true;
  }
  public boolean setPayee(String pay){
    if(pay.equals("")){
      return false;
    }
    payee = pay;
    return true;
  }
  public boolean setPayment(double amount){
    if (amount<0){
      return false;
    }
    paid = amount;
    return true;
  }

  public int getMonth(){
    return payMonth;
  }
  public int getDay(){
    return payDay;
  }
  public double getPaid(){
    return paid;
  }
  public String getCategory(){
    return category;
  }

  @Override
  public int compareTo(Expense expense){
    int compare = this.payMonth - expense.getMonth();
    if (compare ==0){
      return this.payDay - expense.getDay();
    }
    return compare;
  }
  
  /**Creates a string representation of an Expense
  @return String containing all relevant Expense information
  */
  @Override
  public String toString(){
    return payMonth+"/"+payDay+" "+payee+" "+paid+" "+category;
  }
}