import java.util.Scanner;

public class rentInput{
  private rentRecord records = new rentRecord();

  /**Through user prompts, adds another rent row to the records
  */
  public void create(){
    Scanner in = new Scanner(System.in);
    RentRow rent = new RentRow();
    double paid = -1;
    int month = 0;
    String input;
    boolean success = false;

    while (!success){
      System.out.print("\nEnter tenant's name: ");
      input = in.next();
      success = rent.addTenant(input);
      if (!success){
        System.out.println("Tenant not found.");
        return;
      }
    }

    in.nextLine();
    success = false;
    while (!success){
      System.out.print("\nEnter amount paid (345.67): ");
      input = in.next();
      if (input.indexOf('.')!= -1 && (input.length() -  (input.indexOf('.')+1))>2) {
        System.out.println("Invalid format.");
        continue;
      }
      try{
        paid = Double.parseDouble(input);
        if (paid <0){
          System.out.println("Invalid range.");
          continue;
        }
        success = true;
      }
      catch(NumberFormatException e){
        System.out.println("Invalid format.");
      }
    }

    in.nextLine();
    success = false;
    while (!success){
      System.out.print("\nEnter month rent is for (1-12): ");
      input = in.next();
      try {
        month = Integer.parseInt(input);
        if (month <1 || month>12){
          System.out.println("Invalid range.");
          continue;
        }
        success = true;
      }
      catch(NumberFormatException e){
        System.out.println("Invalid format.");
      }
    }

    rent.addPayment(paid,month);
    records.addRent(rent);
  }

  /**Displays all rent records
  */
  public void display(){
    System.out.println("AptNo Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct  Nov  Dec\n------------------------------------------------------------------");
    System.out.println(records);
  }
  
}