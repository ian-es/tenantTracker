import java.io.*;
import java.util.*;
import java.util.Scanner;

public class tenantList{

  private ArrayList<Tenant> list = new ArrayList<Tenant>();
  /** Default constructor for tenantList, populates internal list with values in the file
  */
  public tenantList(){
    try{
      File dataFile = new File("tenants.txt");
      Scanner readFile = new Scanner(dataFile);
      String input;
      
      while (readFile.hasNext()){
        Tenant tenant = new Tenant();
        input = readFile.next();
        tenant.addApt(Integer.parseInt(input));
        input = readFile.nextLine().trim();
        tenant.addName(input);
        list.add(tenant);
      }
      readFile.close();
    }
    catch(FileNotFoundException fnf){
      System.out.println("Error reading file.");
    }
  }
  
  public boolean addTenant(Tenant tenant){
    list.add(tenant);
    Collections.sort(list);
    try{
      PrintWriter writer = new PrintWriter("tenants.txt");
      
      writer.print(this.toString());
      writer.close();
      return true;
    }
    catch (FileNotFoundException fnf){
      System.out.println("Exception: data file was not found.");
    }
    System.out.println("Error. Tenant was unable to be added to files.");
    return false;
  }
  
  public Tenant find(String name){
    Tenant compare = new Tenant();
    compare.addName(name);
    int idx = list.indexOf(compare);
    if (idx != -1){
      return list.get(idx);
    }
    return null;
  }
  public boolean contains(String name){
    Tenant compare = new Tenant();
    compare.addName(name);
    return list.contains(compare);
  }
  public boolean contains(int aptNum){
    for (Tenant tenant:list){
      if (tenant.getApt() == aptNum){
        return true;
      }
    }
    return false;
  }
  
  @Override
  public String toString(){
    String tenants = "";
      for (int i = 0;i<list.size();i++){
        tenants += list.get(i) + "\n";
      }
    return tenants;
  }
  
}