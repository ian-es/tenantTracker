import java.util.Scanner;

public class userInterface{
  private static Scanner in = new Scanner(System.in);
  private expenseInput expenseInput = new expenseInput();
  private tenantInput tenantInput = new tenantInput();
  private rentInput rentInput = new rentInput();
  
  private char input = ' ';
  
public void displayMainMenu(){
  while (input != 'q'){
    System.out.println("Enter 'i' to input data,\n'd' to display a report,\n'q' to quit program:");
    input = in.next().charAt(0);
    if(input == 'i'){
      displayInputMenu();
    }
    else if(input == 'd'){
      displayDisplayMenu();
    }
    else if(input != 'q'){
      System.out.println("Invalid character.");
    }
  }
  in.close();
}

  public void displayInputMenu(){
    input = ' ';
    Boolean workDone = false; 
    while(!workDone){ 
      System.out.println("Enter 't' to add tenant,\n'r' to record rent payment,\n'e' to record expense:");
      input = in.next().charAt(0);

      if(input == 't'){
        tenantInput.create();
        workDone = true;
      }
      else if (input == 'r'){
        rentInput.create();
        workDone = true;
      }
      else if (input =='e'){
        expenseInput.create();
        workDone = true;
      }
      else{
        System.out.println("Invalid character.");
      }
    }
  }
  public void displayDisplayMenu(){
    input = ' ';
    Boolean workDone = false; 
    while(!workDone){
      System.out.println("Enter 't' to display tenants,\n'r' to display rents\n'e' to display expenses,\n'a' to display annual report:");
      input = in.next().charAt(0);
      
      if(input == 't'){
        tenantInput.display();
        workDone = true;
      }
      else if (input == 'r'){
        rentInput.display();
        workDone = true;
      }
      else if (input =='e'){
        expenseInput.display();
        workDone = true;
      }
      else if (input == 'a'){
        AnnualReport AnnualReport = new AnnualReport();
        AnnualReport.printReport();
        workDone = true;
      }
      else{
        System.out.println("Invalid character.");
      }
    }
  } 
}