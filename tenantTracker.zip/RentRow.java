public class RentRow implements Comparable<RentRow>{
  private int aptNum;
  private double[] amounts = new double[12];
  private tenantList tenants = new tenantList();
  
  /** Constructor for RentRow
  */
  public RentRow(){
  }
  
  public boolean addTenant(String name){
    if (tenants.contains(name)){
      aptNum = tenants.find(name).getApt();
      return true;
    }
    return false;
  }
  
  public boolean setApt(int apt){
    if (apt>99 && apt < 1000){
      aptNum = apt;
      return true;
    }
    return false;
  }
  
  public boolean addPayment(double paid,int month){
    if (month <1 || month >12){ 
      return false;
    }
    amounts[month-1] = paid;
    return true;
  }

  public int getApt(){
    return aptNum;
  }
  public double getPaid(){
    double sum = 0;
    for (double val:amounts){
      sum += val;
    }
    return sum;
  }

  /**Creates a string representation of a rent row
  @return String containing all relevant RentRow information
  */
  @Override
  public String toString(){
    String output = "" + aptNum;
    for (double val:amounts){
      output += (" " +String.format("%,.2f", val));
    }
    return output;
  }

  @Override
  public int compareTo(RentRow rent){
    return this.aptNum - rent.getApt();
  }
}